int mayor(int a, int b, int c); 
int menor(int a, int b, int c);
int division(int a, int b, float &c);

int division(int a, int b, float &c)
	{
		c = a/b;
		return c;
	}

//Definicion de la funcion para obtener el valor menor
int menor(int a, int b, int c)
	{
		int menor;
		if (a<b && a<c)
		{
			menor = a;	
		}else
			{
				if (b<a && b<c) menor=b;
				else menor=c;
			}	
		return menor;
	}

//Definicion de la funcion para obtener el valor mayor
int mayor(int a, int b, int c)
	{
		int mayor;
		if (a>b && a>c)
		{
			mayor = a;	
		}else
			{
				if (b>a && b>c) mayor=b;
				else mayor=c;
			}	
		return mayor;
	}
	