#include <stdio.h>
#include "libreriaTp.h"

int main() 
{
    int n1; 
    int n2; 
    int n3;
    float div;
    
    printf("Ingrese el primer valor: ");
    scanf("%d", &n1); 
    printf("Ingrese el segundo valor: "); 
    scanf("%d", &n2); 
    printf("Ingrese el tercer valor: "); 
    scanf("%d", &n3); 
    
    //Invocacion de las funciones
    printf("El mayor es: %d", mayor(n1, n2, n3)); 
    printf("El menor es: %d", menor(n1, n2, n3)); 
    division(n1, n2, &div);  
    printf("Div: %.2f", div); 
    
    return 0;
}