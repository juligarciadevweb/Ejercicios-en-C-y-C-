#include <stdio.h>

int productoRecursivo2(int a, int b) {
    if (a == 0 || b == 0) {
        return 0;
    } else if (b == 1) {
        return a;
    } else {
        return a + productoRecursivo2(a, b - 1);
    }
}

int main() {
    int a, b;
    printf("Ingrese dos números enteros positivos: ");
    scanf("%d %d", &a, &b);

    if (a > 0 && b > 0) {
        int resultado = productoRecursivo2(a, b);
        printf("El producto de %d y %d es: %d\n", a, b, resultado);
    } else {
        printf("Los números ingresados deben ser enteros positivos.\n");
    }

    return 0;
}
