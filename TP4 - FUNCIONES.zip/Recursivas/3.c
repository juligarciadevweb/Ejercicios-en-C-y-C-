#include <stdio.h>

int factorialRecursivo1(int n) {
    if (n <= 1) {
        return 1;
    } else {
        return n * factorialRecursivo1(n - 1);
    }
}

int main() {
    int x, factorial;
    printf("Ingrese valores enteros positivos (ingrese un número negativo para detener): ");

    scanf("%d", &x);

    while (x >= 0) {
        factorial = factorialRecursivo1(x);
        printf("El factorial de %d es: %d\n", x, factorial);
        scanf("%d", &x);
    }

    return 0;
}
