#include <stdio.h>

// Definición de la función "desechos"
void desechos(int totalEnv, int m1f, int m2f, int m3f) 
{
    printf("\nDesechos");
    float d1 = (100.0 / totalEnv) * m1f;
    float d2 = (100.0 / totalEnv) * m2f;
    float d3 = (100.0 / totalEnv) * m3f;
    printf("\nPorcentaje desechos Maquina 1: %.2f", d1);
    printf("\nPorcentaje desechos Maquina 2: %.2f", d2);
    printf("\nPorcentaje desechos Maquina 3: %.2f", d3);
}

// Llamada de la función "desechos"
void desechos(int totalEnv, int m1f, int m2f, int m3f);

int main() {
    int m, env, fallas;
    int m1e = 0, m2e = 0, m3e = 0;
    int m1f = 0, m2f = 0, m3f = 0;

    printf("Ingrese maquina: ");
    scanf("%d", &m);

    while (m != 0) {
        printf("Ingrese cant de envases: ");
        scanf("%d", &env);

        printf("Ingrese cant fallados: ");
        scanf("%d", &fallas);

        // Actualizamos los totales de envases y fallas para la máquina correspondiente
        switch (m) 
        {
            case 1:
                m1e += env;
                m1f += fallas;
                break;
            case 2:
                m2e += env;
                m2f += fallas;
                break;
            case 3:
                m3e += env;
                m3f += fallas;
                break;
        }

        printf("\nIngrese maquina: ");
        scanf("%d", &m);
    }

    int totalEnv = m1e + m2e + m3e;
    printf("\nLa cantidad total de envases producidos: %d", totalEnv);

    desechos(totalEnv, m1f, m2f, m3f);

    return 0;
}
