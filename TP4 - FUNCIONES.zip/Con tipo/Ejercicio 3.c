#include<stdio.h>
#include<stdlib.h>

// Convertir el valor a horas
int convertirHoras(int valor) 
    {
        int horas = valor / 60; 
        return horas; 
    }

// Convertir el valor a minutos
int convertirMinutos(int valor) 
    {
        int minutos = valor; 
        return minutos; 
    }

// Convertir el valor a segundos
int convertirSegundos(int valor) 
    {
        int segundos = valor * 60; 
        return segundos; 
    }

int main() 
{
    int valor;
    printf("Ingrese un valor superior a 600, representando una cantidad de minutos: ");
    scanf("%d", &valor); 
    printf("\nHoras: %d", convertirHoras(valor));        
    print("\nMinutos: %d", convertirMinutos(valor));     
    printf("\nSegundos: %d", convertirSegundos(valor)); 
    return 0;
}
