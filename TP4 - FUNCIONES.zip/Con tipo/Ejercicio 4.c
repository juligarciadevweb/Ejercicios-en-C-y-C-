#include<stdio.h>

// Función para obtener el porcentaje de pares
float porcentajePares(int c, float p) 
    {
        return (100.0 / c) * p;
    }

// Función para calcular el promedio de los impares
float promedioImpares(int i, int sumaImpares) 
    {
        return sumaImpares / (float) i;
    }

int main() 
{
    int c = 0;
    int N, nro, i = 0, sumaImpares = 0;
    float p = 0;
    
    printf("Ingrese N: ");
    scanf("%d", &N);
    
    while (c < N) 
    {
        printf("Ingrese nro: ");
        scanf("%d", &nro);
        
        if (nro % 2 == 0)
            p++; // Incrementamos la cantidad de pares
        else 
        {
            sumaImpares += nro; // Sumamos el número a la suma de impares
            i++;
        }    
        c++;
    }
    
    // Impresión de resultados en pantalla
    printf("\nPares: %.0f | Impares: %d | Totales: %d\n", p, i, c);
    p = porcentajePares(c, p);
    printf("Porcentaje de pares: %.2f", p);
    printf("\nPromedio impares: %.2f", promedioImpares(i, sumaImpares));
    
    return 0;
}
