#include <stdio.h>

// Función Cuadrado
int Cuadrado(int x, int N) {
    int num;
    int suma = 0;

    for (int i = 0; i < N; i++) {
        printf("Ingrese un número: ");
        scanf("%d", &num);

        if (num % 2 == 0) {
            printf("Error, ingrese otro valor\n");
        } else {
            printf("Es impar\n");
            suma += num;
        }
    }

    return suma;
}

int main() {
    int x, s, N;

    printf("Ingrese x número: ");
    scanf("%d", &x);

    printf("Ingrese N: ");
    scanf("%d", &N);

    s = Cuadrado(x, N); // Invocación de la función en una variable

    printf("El número ingresado es %d\n", x);
    printf("El cuadrado de %d es %d\n", x, s);

    return 0;
}
