#include <stdio.h>

// Prototipo de la función para calcular la superficie del cuadrado
int calcularSuperficieCuadrado(int lado);

// Prototipo de la función para calcular la superficie del círculo
float calcularSuperficieCirculo(int radio);

// Prototipo de la función para determinar el mayor y el menor
void determinarMayorMenor(int num1, int num2, int* mayor, int* menor);

int main() {
    int num1, num2;
    printf("Ingrese el primer número: ");
    scanf("%d", &num1);
    printf("Ingrese el segundo número: ");
    scanf("%d", &num2);

    int mayor, menor;
    determinarMayorMenor(num1, num2, &mayor, &menor);
    printf("El mayor número es: %d\n", mayor);
    printf("El menor número es: %d\n", menor);

    int superficieCuadrado = calcularSuperficieCuadrado(mayor);
    printf("La superficie del cuadrado es: %d\n", superficieCuadrado);

    float superficieCirculo = calcularSuperficieCirculo(menor);
    printf("La superficie del círculo es: %.2f\n", superficieCirculo);

    return 0;
}

// Definición de la función para calcular la superficie del cuadrado
int calcularSuperficieCuadrado(int lado) 
{
    return lado * lado;
}

// Definición de la función para calcular la superficie del círculo
float calcularSuperficieCirculo(int radio) 
{
    const float PI = 3.14159;
    return PI * radio * radio;
}

// Definición de la función para determinar el mayor y el menor
void determinarMayorMenor(int num1, int num2, int* mayor, int* menor) 
{
    if (num1 > num2) 
    {
        *mayor = num1;
        *menor = num2;
    } else 
    {
        *mayor = num2;
        *menor = num1;
    }
}
