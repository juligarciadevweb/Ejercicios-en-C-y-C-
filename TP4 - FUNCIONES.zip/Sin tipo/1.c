#include <stdio.h>

// Prototipo de la función intervalo
void intervalo(float A, float B, int N);

int main() 
{
    float A, B;
    int N;

    printf("Ingrese el límite inferior del intervalo: ");
    scanf("%f", &A);

    printf("Ingrese el límite superior del intervalo: ");
    scanf("%f", &B);

    printf("Ingrese la cantidad de números a ingresar: ");
    scanf("%d", &N);

    intervalo(A, B, N); // Invocación de la función intervalo

    return 0;
}

// Definición de la función intervalo
void intervalo(float A, float B, int N) {
    float num;
    int dentro = 0;
    int fuera = 0;

    for (int i = 0; i < N; i++) {
        printf("Ingrese un número: ");
        scanf("%f", &num);

        if (num > A && num <= B) {
            dentro++;
        } else {
            fuera++;
        }
    }

    printf("Cantidad de valores dentro del intervalo: %d\n", dentro);
    printf("Cantidad de valores fuera del intervalo: %d\n", fuera);
}
