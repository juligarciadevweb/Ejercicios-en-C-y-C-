#include <stdio.h>

// Declaración de la función sin tipo para encontrar los primeros 10 múltiplos comunes
void primerosMultiplosComunes(int num1, int num2);

int main() {
    int N;
    printf("Ingrese la cantidad de duplas de valores: ");
    scanf("%d", &N);

    for (int i = 0; i < N; i++) {
        int num1, num2;
        printf("Ingrese el primer número (entre 1 y 9): ");
        scanf("%d", &num1);
        printf("Ingrese el segundo número (entre 1 y 9): ");
        scanf("%d", &num2);

        printf("Primeros 10 múltiplos comunes de %d y %d:\n", num1, num2);
        primerosMultiplosComunes(num1, num2);
        printf("\n");
    }

    return 0;
}

// Definición de la función sin tipo para encontrar los primeros 10 múltiplos comunes
void primerosMultiplosComunes(int num1, int num2) {
    int count = 0;
    int i = 1;

    while (count < 10) {
        if (i % num1 == 0 && i % num2 == 0) {
            printf("%d ", i);
            count++;
        }
        i++;
    }
}

