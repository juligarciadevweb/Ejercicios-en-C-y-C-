#include <stdio.h>

// Prototipo de la función para realizar la suma
void suma(int N, float* resultado);

int main() {
    int N;
    printf("Ingrese la cantidad de números a sumar: ");
    scanf("%d", &N);

    float resultado;
    suma(N, &resultado);

    printf("La suma de los %d números ingresados es: %.2f\n", N, resultado);

    return 0;
}

// Definición de la función para realizar la suma
void suma(int N, float* resultado) {
    *resultado = 0;
    float numero;

    for (int i = 0; i < N; i++) {
        printf("Ingrese el número %d: ", i + 1);
        scanf("%f", &numero);
        *resultado += numero;
    }
}
